#encoding=utf-8
import time
import base64
import struct
import logging
from pyDes import *

def decrypt(uid):
    raw = struct.pack("!Q", uid)
    key = "\x01\x09\x09\x00\x00\x07\x01\x03"
    k = des("DESCRYPT", CBC, key, pad=None, padmode=None)
    d = k.decrypt(raw)
    r = struct.unpack("!Q", d)[0]
    return r

def encrypt(uid):
    raw = struct.pack("!Q", uid)
    key = "\x01\x09\x09\x00\x00\x07\x01\x03"
    k = des("DESCRYPT", CBC, key, pad=None, padmode=None)
    d = k.encrypt(raw)
    r = struct.unpack("!Q", d)[0]
    return r

def deAccessToken(uid):
    raw = struct.pack("!Q", uid)
    key = "\x22\x33\x35\x81\xBC\x38\x5A\xE7"
    k = des("DEUSERID", CBC, key, pad=None, padmode=None)
    d = k.decrypt(raw)
    r = struct.unpack("!Q", d)[0]
    return r

def enAccessToken(uid):
    raw = struct.pack("!Q", uid)
    key = "\x22\x33\x35\x81\xBC\x38\x5A\xE7"
    k = des("DEUSERID", CBC, key, pad=None, padmode=None)
    d = k.encrypt(raw)
    r = struct.unpack("!Q", d)[0]
    return r

if __name__ == '__main__':
    user_id = 5881107857
    print encrypt(user_id)
    # print decrypt(user_id)