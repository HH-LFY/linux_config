# -*- coding: utf-8 -*-
import logging
import util.connection_pool as connection_pool
from baseclient import python as BaseClient
import baseclient.python.gclient as gclient
import baseclient.python.proto_gclient as proto_gclient
import baseclient.python.module as module
import signal
from datetime import datetime
from datetime import timedelta
import time
import base64
import random
import md5
import urllib2
from util.common_util import *
from xml.etree import ElementTree
import urllib
import json
import hashlib
import socket
import MySQLdb.cursors
import baseclient.python.module_pb2 as proto_theia
from ast import literal_eval as make_tuple
import copy

#---------------- SQL语句 ----------------
SQL_SELECT_SELF_TOPIC_BY_USERID = '''
select * from
chat_room_topic, andes_user
where chat_room_topic.chat_room_topic_author_id = %s
and chat_room_topic.chat_room_topic_enable = 0
and chat_room_topic.chat_room_topic_author_id = andes_user.user_id
limit 1
'''
SQL_SELECT_TOPIC_LIST = '''
select * from
chat_room_topic as a, andes_user as b
where a.chat_room_topic_enable = 0
and a.chat_room_topic_report_end_time is NULL
and a.chat_room_topic_author_id != %s
and a.chat_room_topic_id not in(
    select chat_room_topic_id from
    chat_room_topic_report
    where chat_room_topic_reporter_id = %s
)
and a.chat_room_topic_author_id = b.user_id
and a.chat_room_topic_submit_time < %s
order by chat_room_topic_submit_time desc
limit %s
'''

SQL_UPDATE_TOPIC_ENABLE = '''
update chat_room_topic set chat_room_topic_enable=1,chat_room_topic_end_time=now()
where chat_room_topic_id=%s
'''

SQL_INSERT_TOPIC = '''
insert into chat_room_topic(chat_room_topic_author_id,chat_room_topic_content)
values(%s,%s)
'''

SQL_INSERT_TOPIC_REPORT = '''
insert into chat_room_topic_report(chat_room_topic_id,chat_room_topic_reporter_id,chat_room_report_type)
values(%s,%s,%s)
'''

SQL_UPDATE_TOPIC_CLICK_COUNT = '''
update chat_room_topic set chat_room_topic_click_count=chat_room_topic_click_count+1
where chat_room_topic_id = %s and chat_room_topic_enable = 0
'''

SQL_SELECT_WHITE_BY_PHONE = '''
select phone from
chat_room_white_list
where phone=%s
'''

SQL_UPDATE_TOPIC_REPORT_TIME_1 = '''
update chat_room_topic set chat_room_topic_report_end_time = now()
where chat_room_topic_id=%s
and chat_room_topic_report_end_time is NULL
'''

SQL_UPDATE_TOPIC_REPORT_TIME_2 = '''
update chat_room_topic set chat_room_topic_report_end_time = now()
where chat_room_topic_id in (
    select chat_room_topic_id from
    chat_room_topic_report
    where chat_room_topic_id = %s
    group by chat_room_topic_id
    having count(*)=3
)and chat_room_topic_report_end_time is NULL
'''

# 举报反馈文案
REC_REPORT_TEXT = {
    "2000":"举报成功",
    "4001":"已经举报过了",
}

class ChatRoomSession(proto_gclient.ProtoAsyncSession):

    def __init__(self, service, oid, package, is_message):
        super(ChatRoomSession, self).__init__(service, oid, package,is_message)

# 入口
    def on_srv_call_ChatRoomRequest(self,pkg):
        logging.info('user_id:%s. call module on_srv_call_ChatRoomRequest.',pkg.user_id)
        try:
            if pkg.action == proto_theia.ChatRoomRequest.GET_TOPIC:
                return self.on_get_topic(pkg)
            elif pkg.action == proto_theia.ChatRoomRequest.TOPIC_OPERATION:
                return self.on_topic_operation(pkg)
            elif pkg.action == proto_theia.ChatRoomRequest.TOPIC_REPORT:
                return self.on_topic_report(pkg)
            elif pkg.action == proto_theia.ChatRoomRequest.TOPIC_CLICK_TO_CHAT:
                return self.on_topic_click_to_chat(pkg)

            elif pkg.action == proto_theia.ChatRoomRequest.DEBUG_ADD_DATA:
                return self.debug_add_data(pkg)
            else:
                assert(False)
        except :
            logging.error('module exception!', exc_info = True)


#---------------- 具体逻辑 ----------------

    @gclient.in_thread
    def on_get_topic(self,pkg):
        logging.info('on_get_topic is start.')
        logging.info('req data: %s', pkg)
        ret = proto_theia.ChatRoomResponse()
        res = {}
        try:
            res['topic_list'] = []
            if pkg.last_time == '0':
                self_topic = self.__do_select_self_topic(pkg.user_id)
                if self_topic:
                    res['topic_list'].append(self_topic)

            if pkg.last_time == '0':
                pkg.last_time = str(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
            else:
                pkg.last_time = str(datetime.fromtimestamp(int(pkg.last_time)))

            other_topics = self.__do_select_all_topic(pkg.user_id,pkg.last_time,(int(pkg.page_num)+1))
            if other_topics:
                res['topic_list'].extend(other_topics)

            # 判断是否还有 "下一页",0代表有，1代表无
            res['without_data'] = '0'
            logging.debug('========%s==%s=====',len(other_topics),int(pkg.page_num))
            if len(other_topics) != int(pkg.page_num):
                res['without_data'] = '1'

        except:
            logging.error('on_get_topic info is error.',exc_info=True)

        ret.result = json.dumps(res, encoding = 'utf-8',cls=ChatRoomEncode)
        return ret

    @gclient.in_thread
    def on_topic_operation(self,pkg):
        logging.info('on_topic_operation is start.')
        logging.info('req data: %s', pkg)
        ret = proto_theia.ChatRoomResponse()
        res = {}
        try:
            len_content = len(pkg.topic_content)
            # logging.debug('len_content:%s',len_content)
            if len_content > 30:
                logging.error('user_id:%s topic_content is too long!',pkg.user_id)
                raise False

            self_topic = self.__do_select_self_topic(pkg.user_id)
            if pkg.topic_content and self_topic:
                # 更新话题
                self_topic_content = self_topic.get('topic_info').get('topic_content').decode('utf-8')
                if self_topic_content != pkg.topic_content:
                    self.__do_insert_and_update_self_topic(pkg.user_id,pkg.topic_content,need_update_topic_id=self_topic.get('topic_info').get('topic_id'))
            elif self_topic == {} and pkg.topic_content:
                # 新发布话题
                self.__do_insert_and_update_self_topic(pkg.user_id,pkg.topic_content,need_update=False)
            elif pkg.topic_content == '' and self_topic:
                # 删除话题
                self.__do_insert_and_update_self_topic(pkg.user_id,pkg.topic_content,need_update_topic_id=self_topic.get('topic_info').get('topic_id'),need_insert=False)

            now_self_topic = self.__do_select_self_topic(pkg.user_id)
            res = now_self_topic
        except:
            logging.error('on_topic_operation info is error.',exc_info=True)

        ret.result = json.dumps(res, encoding = 'utf-8',cls=ChatRoomEncode)
        return ret

    @gclient.in_thread
    def on_topic_report(self,pkg):
        logging.info('on_topic_report is start.')
        logging.info('req data: %s', pkg)
        ret = proto_theia.ChatRoomResponse()
        res = "2000"
        try:
            is_white = self.__do_select_whether_white_user(pkg.user_phone)
            if is_white:
                judge = self.__do_insert_report(pkg.topic_id,pkg.user_id,report_type=1)
            else:
                judge = self.__do_insert_report(pkg.topic_id,pkg.user_id)
            if judge == False:
                res = "4001"
        except:
            logging.error('on_topic_report info is error.',exc_info=True)
            res = "4001"

        res = REC_REPORT_TEXT[res]
        ret.result = json.dumps(res, encoding = 'utf-8',cls=ChatRoomEncode)
        return ret

    @gclient.in_thread
    def on_topic_click_to_chat(self,pkg):
        logging.info('on_topic_click_to_chat is start.')
        logging.info('req data: %s', pkg)
        ret = proto_theia.ChatRoomResponse()
        res = "suc"
        try:
            judge = self.__do_update_topic_click_account(pkg.topic_id,pkg.user_id)
            if judge == False:
                res = "fail"
        except:
            logging.error('on_topic_report info is error.',exc_info=True)
            res = "fail"

        ret.result = json.dumps(res, encoding = 'utf-8',cls=ChatRoomEncode)
        return ret

    @gclient.in_thread
    def debug_add_data(self,pkg):
        logging.debug('start debug_add_data.')
        try:
            conn = self.service.conn_pool_ro.connect()
            cur = conn.cursor()
            cur.execute("select user_id from andes_user where head_image_url>=''; ")
            rows = cur.fetchall()
            len_rows = len(rows)
            for x in xrange(len_rows):
                item = rows[x]
                user_id = item['user_id']
                topic_content = 'test'+str(x)
                logging.debug('user_id:%s',user_id)
                logging.debug('topic_content:%s',topic_content)
                cur.execute("update chat_room_topic set chat_room_topic_enable=1,chat_room_topic_end_time=now() where chat_room_topic_author_id=%s",user_id)
                self.__do_insert_and_update_self_topic(user_id,topic_content)
                time.sleep(1)
        except:
            logging.error(' debug_add_data is error.',exc_info=True)
        finally:
            cur.close()
            conn.close()
        return  proto_theia.ChatRoomResponse()

#---------------- 数据库交互 ----------------

    def __do_select_self_topic(self,user_id):
        logging.info('call __do_select_self_topic.')
        res = {}
        try:
            conn = self.service.conn_pool_ro.connect()
            cur = conn.cursor()
            cur.execute(SQL_SELECT_SELF_TOPIC_BY_USERID,(user_id,))
            row = cur.fetchone()
            logging.debug(row)
            if row:
                res['is_self'] = '1'

                topic_info = {}
                topic_info['topic_id'] = str(row.get('chat_room_topic_id'))
                topic_info['topic_content'] = row.get('chat_room_topic_content')
                topic_info['topic_time'] = row.get('chat_room_topic_submit_time')
                topic_info['topic_whether_report'] = '0'
                judge = row.get('chat_room_topic_report_end_time')
                if judge:
                    topic_info['topic_whether_report'] = '1'

                res['topic_info'] = topic_info

                user_info = {}
                user_info['user_id'] = encrypt(int(row.get('user_id')))
                user_info['nickname'] = row.get('nick_name')
                user_info['age'] = row.get('age_group')
                user_info['avatar'] = row.get('head_image_url')
                user_info['sex'] = row.get('gender')

                res['user_info'] = user_info

        except:
            logging.error(' __do_select_self_topic is error.',exc_info=True)
        finally:
            cur.close()
            conn.close()
        return res

    def __do_select_all_topic(self,user_id,last_time,page_num):
        logging.info('call __do_select_all_topic.')
        res = []
        try:
            conn = self.service.conn_pool_ro.connect()
            cur = conn.cursor()
            logging.info('user_id:%s',user_id)
            logging.info('last_time:%s',last_time)
            logging.info('page_num:%s',page_num)
            cur.execute(SQL_SELECT_TOPIC_LIST,(user_id,user_id,last_time,page_num))
            rows = cur.fetchall()
            logging.debug(rows)
            if rows:
                len_rows = len(rows)
                if len_rows == page_num:
                    len_rows = len_rows - 1
                for i in xrange(len_rows):
                    row = rows[i]

                    item = {}
                    item['is_self'] = '0'

                    topic_info = {}
                    topic_info['topic_id'] = str(row.get('chat_room_topic_id'))
                    topic_info['topic_content'] = row.get('chat_room_topic_content')
                    topic_info['topic_time'] = row.get('chat_room_topic_submit_time')
                    topic_info['topic_whether_report'] = '0'
                    item['topic_info'] = topic_info

                    user_info = {}
                    user_info['user_id'] = encrypt(int(row.get('user_id')))
                    user_info['nickname'] = row.get('nick_name')
                    user_info['age'] = row.get('age_group')
                    user_info['avatar'] = row.get('head_image_url')
                    user_info['sex'] = row.get('gender')
                    item['user_info'] = user_info

                    res.append(item)
        except:
            logging.error(' __do_select_all_topic is error.',exc_info=True)
        finally:
            cur.close()
            conn.close()
        return res

    def __do_insert_and_update_self_topic(self,user_id,topic_content,need_update_topic_id=None,need_update=True,need_insert=True):
        logging.info('user_id:%s __do_insert_and_update_self_topic.',user_id)
        res = False
        try:
            conn = self.service.conn_pool.connect()
            # cursor2 为不默认commit的链接
            cur = conn.cursor2()
            if need_update:
                cur.execute(SQL_UPDATE_TOPIC_ENABLE,(need_update_topic_id,))
            if need_insert:
                cur.execute(SQL_INSERT_TOPIC,(user_id,topic_content))

            conn.commit()
            res = True
        except :
            cur.execute('rollback')
            logging.error('user_id:%s __do_insert_and_update_self_topic is error.',user_id,exc_info=True)
        finally:
            cur.close()
            conn.close()

        return res

    def __do_select_whether_white_user(self,user_phone):
        logging.info('user_phone:%s __do_select_whether_white_user.',user_phone)
        res = False
        try:
            conn = self.service.conn_pool_ro.connect()
            cur = conn.cursor()
            cur.execute(SQL_SELECT_WHITE_BY_PHONE,(user_phone,))
            row = cur.fetchone()
            if row:
                res = True

        except :
            logging.error('user_phone:%s __do_select_whether_white_user is error.',user_phone,exc_info=True)
        finally:
            cur.close()
            conn.close()

        return res

    def __do_insert_report(self,topic_id,user_id,report_type = 0):
        logging.info('user_id:%s __do_insert_report.',user_id)
        res = False
        try:
            conn = self.service.conn_pool.connect()
            # cursor2 为不默认commit的链接
            cur = conn.cursor2()
            cur.execute(SQL_INSERT_TOPIC_REPORT,(topic_id,user_id,report_type))
            conn.commit()
            if report_type == 1:
                cur.execute(SQL_UPDATE_TOPIC_REPORT_TIME_1,(topic_id,))
            else:
                cur.execute(SQL_UPDATE_TOPIC_REPORT_TIME_2,(topic_id,))
            conn.commit()
            res = True
        except :
            cur.execute('rollback')
            logging.error('user_id:%s __do_insert_report is error.',user_id,exc_info=True)
        finally:
            cur.close()
            conn.close()

        return res

    def __do_update_topic_click_account(self,topic_id,user_id):
        logging.info('user_id:%s __do_update_topic_click_account.',user_id)
        res = False
        try:
            conn = self.service.conn_pool.connect()
            # cursor2 为不默认commit的链接
            cur = conn.cursor2()
            cur.execute(SQL_UPDATE_TOPIC_CLICK_COUNT,(topic_id,))
            conn.commit()
            res = True
        except :
            cur.execute('rollback')
            logging.error('user_id:%s __do_update_topic_click_account is error.',user_id,exc_info=True)
        finally:
            cur.close()
            conn.close()

        return res


# jsonEncoder
class ChatRoomEncode(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime):
            return int(time.mktime(obj.timetuple()))
        elif isinstance(obj, date):
            return obj.strftime('%Y-%m-%d')
        else:
            return json.JSONEncoder.default(self, obj)

class ChatRoomModule(gclient.ServiceBase):
    def __init__(self,config):
        self.proto = proto_theia
        super(ChatRoomModule, self).__init__(config['router']['host'],
                                             str(config['router']['port']),
                                             BaseClient.MODULE_CHAT_ROOM,
                                             config['host_id'],
                                             enable_server=True,
                                             session_maker=ChatRoomSession)
        config['db_info']['cursorclass'] = MySQLdb.cursors.DictCursor
        self.conn_pool = connection_pool.ConnectionPool(**config['db_info'])
        config['db_info_ro']['cursorclass'] = MySQLdb.cursors.DictCursor
        self.conn_pool_ro = connection_pool.ConnectionPool(**config['db_info_ro'])
        self.start_thread_pool(config['thread_pool_num'])

    def start(self):
        self.loop()

    def stop(self):
        super(ChatRoomModule, self).stop()

    def on_signal(self, sig):
        if sig == signal.SIGINT:
            self.stop()