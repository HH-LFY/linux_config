聊天室1v1聊天服务器端设计文档
======================================

[toc]


##更新情况

###2016-6-22 18:34:11 更新
**更新原因**
*　线上数据库版本过低，某些语法不支持

**更新内容**
* 数据库默认值修改

###2016-6-21 14:26:52 更新
**更新原因**
* 新增数据埋点需求:https://magiclink.teambition.com/shares/594a11de10142c6bce626b6f


**更新内容**
* 向聊天室－话题表添加新字段：chat_room_topic_report_end_time
* 向聊天室-话题举报表填写新字段：chat_room_topic_report_time

###2016-6-20 22:06:02 更新
**更新原因**
* 需求简单变更

**更新内容**
* 向聊天室－话题表添加新字段：chat_room_topic_end_time,chat_room_topic_click_count
* 向聊天室-话题举报表填写新字段：chat_room_report_type
* 添加新表：聊天室白名单表
* 添加新接口：用户点击话题进行聊天数量统计接口/chat_room/topic_click_to_chat

##相关地址
测试地址：http://121.52.235.231:40030
线上地址：http://touchlife.cootekservice.com

##数据库设计
注：目前所有表创建在oceanus下

###聊天室－话题表：chat_room_topic

话题表：用于记录话题内容，话题发布时间等信息

其字段如下：
```
chat_room_topic_id              //话题id
chat_room_topic_content         //话题内容
chat_room_topic_author_id       //话题发布者id
chat_room_topic_submit_time     //话题发布时间
chat_room_topic_report_end_time //话题被举报导致下线的时间
chat_room_topic_end_time        //话题正式下线时间
chat_room_topic_click_count     //话题被点击次数
chat_room_topic_enable          //是否有效，0代表有效，1代表无效
```
创建脚本:
```
CREATE TABLE IF NOT EXISTS `chat_room_topic` (
  `chat_room_topic_id` int(11) NOT NULL AUTO_INCREMENT,
  `chat_room_topic_content` varchar(70),
  `chat_room_topic_author_id` varchar(70),
  `chat_room_topic_submit_time` datetime DEFAULT NULL,
  `chat_room_topic_report_end_time` datetime DEFAULT NULL,
  `chat_room_topic_end_time` datetime DEFAULT NULL,
  `chat_room_topic_click_count` int DEFAULT 0,
  `chat_room_topic_enable` int DEFAULT 0,
  PRIMARY KEY (`chat_room_topic_id`),
  INDEX(`chat_room_topic_author_id`),
  INDEX(`chat_room_topic_submit_time`)
) AUTO_INCREMENT = 100000 DEFAULT CHARSET=utf8;
```

###聊天室－话题举报表：chat_room_topic_report

话题表举报表：用于记录话题被哪些用户举报

其字段如下：
```
chat_room_topic_id              //话题id
chat_room_topic_reporter_id     //举报用户的id
chat_room_topic_report_time     //举报时间
chat_room_report_type           //被举报的类别 0 为被普通用户举报，1为被管理员用户举报
```
创建脚本：
```
CREATE TABLE IF NOT EXISTS `chat_room_topic_report` (
  `chat_room_topic_id` int(11) NOT NULL,
  `chat_room_topic_reporter_id` varchar(70) NOT NULL,
  `chat_room_topic_report_time` datetime DEFAULT NULL,
  `chat_room_report_type` int DEFAULT 0,
  INDEX(`chat_room_topic_id`),
  INDEX(`chat_room_topic_reporter_id`),
  UNIQUE(`chat_room_topic_id`,`chat_room_topic_reporter_id`)
)  DEFAULT CHARSET=utf8;
```


###聊天室-白名单表：chat_room_white_list
白名单表：用于设置聊天室所有白名单用户
```
phone     //电话号码
type      //类型
add_time  //添加时间
remark    //备注
```

其字段如下：

创建脚本：
```
CREATE TABLE `chat_room_white_list` (
  `phone` varchar(50) NOT NULL,
  `type`int DEFAULT 0,
  `add_time` datetime DEFAULT now(),
  `remark` varchar(200) DEFAULT NULL,
  INDEX(`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
```
##系统接口定义

###**系统请求参数**

<table border="1" class="table table-bordered table-condensed">
       <tr bgcolor="#6086e7" height="35px">
           <td width="100px">参数名</td>
           <td width="100px">参数类型</td>
           <td>参数描述</td>
       </tr>
       <tr bgcolor=grey height="35px"><td colspan=3>必选参数</td></tr>
       <tr>
           <td>_v</td>
           <td>NUMBER</td>
           <td>表示API版本，目前为3</td>
       </tr>
       <tr>
           <td>_token</td>
           <td>STRING</td>
           <td>从v3版本开始，token为必选参数，所有API都需要进行token的验证</td>
       </tr>
       <tr bgcolor=grey height="35px"><td colspan=3>需要签名时必选参数</td></tr>
       <tr>
           <td>_ts</td>
           <td>NUMBER</td>
           <td>timestamp，UTC秒数</td>
       </tr>
       <tr>
           <td>_sign</td>
           <td>STRING</td>
           <td>请求签名，签名规范见"签名"</td>
       </tr>
</table>
###**系统返回参数**
系统返回分为两种方式：html 和 json，默认json。根据请求header中的“Content-Type”进行区分。对于html，header中的“Content-Type”为'text/html'，而json，header中的“Content-Type”为‘application/json‘。参数描述如下：

<table border="1" class="table table-bordered table-condensed">
       <tr bgcolor="#6086e7" height="35px">
         <td width="100px">参数名</td>
         <td width="100px">参数类型</td>
         <td>参数描述</td>
     </tr>
     <tr bgcolor=grey height="35px"><td colspan=3>必选参数</td></tr>
     <tr>
         <td>req_id</td>
         <td>NUMBER</td>
         <td>请求编号，用于诊断</td>
     </tr>
     <tr>
         <td>result_code</td>
         <td>NUMBER</td>
         <td>返回码（具体描述见下一节）</td>
     </tr>
     <tr>
         <td>timestamp</td>
         <td>STRING</td>
         <td>用于客户端时间戳校验</td>
     </tr>
     <tr>
         <td>result</td>
         <td>JSON</td>
         <td>业务结果，内容由具体API决定</td>
     </tr>
     <tr>
         <td>err_msg</td>
         <td>STRING</td>
         <td>和result_code对应的错误信息</td>
     </tr>
</table>

###**状态码**

<table border="1" class="table table-bordered table-condensed">
<tr bgcolor="#6086e7" height="35px">
   <td width="100px">错误码</td>
   <td>错误码描述</td>
</tr>
<tr>
   <td>2000</td>
   <td>访问成功。</td>
</tr>
<tr>
   <td>4001</td>
   <td>缺少签名。</td>
</tr>
<tr>
   <td>4002</td>
   <td>签名无效。</td>
</tr>
<tr>
   <td>4003</td>
   <td>token无效。</td>
</tr>
<tr>
   <td>4004</td>
   <td>账号未登录。</td>
</tr>
<tr>
   <td>4005</td>
   <td>缺少app_key。</td>
</tr>
<tr>
   <td>4006</td>
   <td>请求过时。</td>
</tr>
<tr>
   <td>4031</td>
   <td>客户端访问过频。</td>
</tr>
<tr>
   <td>5001</td>
   <td>服务器内部错误。</td>
</tr>
</table>
##业务接口定义
###**(1) 获取话题列表接口：/chat_room/get_topic**

**请求方法**
GET

**请求参数**
|参数名称|参数类型|参数描述|可为空|备注|
|-------|-------|------|----|
|last_time|string|最后一个话题的时间戳|是|为空时意味着获取最新的话题，同时会返回self_topic|
|page_num|number|获取的数量|是|为空时意味着为２０|


**响应参数**
TODO

**示例**

响应结果：
```
{
    "is_ios": false,
    "timestamp": "1494233311",
    "err_msg": "OK",
    "result": {
        "topic_list":[{
                "is_self":"1",
                "topic_info":{
                    "topic_id":"话题ＩＤ",
                    "topic_content":"话题内容",
                    "topic_time":"1494233311(时间戳)",
                    "topic_whether_report":"１（１代表被举报）"
                },
                "user_info":{
                    "user_id": "9223372036854765807",
                    "nickname": "传说中的小哥哥",
                    "age": "after_80",
                    "avatar": "http://cootek-dialer-download.oss-cn-hangzhou.aliyuncs.com/social_head/head/2255590324019366691.png",
                    "sex": "male"
                }
            },
            {
                "is_self":"0",
                "topic_info":{
                    "topic_id":"话题ＩＤ",
                    "topic_content":"话题内容",
                    "topic_time":"1494233311(时间戳)"
                },
                "user_info":{
                    "user_id": "9223372036854765807",
                    "nickname": "传说中的小哥哥",
                    "age": "after_80",
                    "avatar": "http://cootek-dialer-download.oss-cn-hangzhou.aliyuncs.com/social_head/head/2255590324019366691.png",
                    "sex": "male"
                }
            },
            {
                "is_self":"0",
                "topic_info":{
                    "topic_id":"话题ＩＤ",
                    "topic_content":"话题内容",
                    "topic_time":"1494233311(时间戳)"
                },
                "user_info":{
                    "user_id": "9223372036854765807",
                    "nickname": "传说中的小哥哥",
                    "age": "after_80",
                    "avatar": "http://cootek-dialer-download.oss-cn-hangzhou.aliyuncs.com/social_head/head/2255590324019366691.png",
                    "sex": "male"
                }
            },
            {
                "is_self":"0",
                "topic_info":{
                    "topic_id":"话题ＩＤ",
                    "topic_content":"话题内容",
                    "topic_time":"1494233311(时间戳)"
                },
                "user_info":{
                    "user_id": "9223372036854765807",
                    "nickname": "传说中的小哥哥",
                    "age": "after_80",
                    "avatar": "http://cootek-dialer-download.oss-cn-hangzhou.aliyuncs.com/social_head/head/2255590324019366691.png",
                    "sex": "male"
                }
            }
        ],
        "without_data":"0(0代表有，1代表没有)"
      },
    "req_id": 0,
    "result_code": 2000
}
```
###**(2) 用户操作话题接口：/chat_room/topic_operation**

**请求方法**
POST

**请求参数**
|参数名称|参数类型|参数描述|可为空|备注|
|-------|-------|------|----|
|topic_id|string|话题的ｉｄ|是|删除的时候尽量传入|
|topic_content|string|话题的内容|是|为空的时候表示为删除话题,删除话题时result返回suc|


**响应参数**
TODO

**示例**

响应结果：
```
{
    "is_ios": false,
    "timestamp": "1494233311",
    "err_msg": "OK",
    "result": {
      "is_self":"1",
      "topic_info":{
          "topic_id":"话题ＩＤ",
          "topic_content":"话题内容",
          "topic_time":"1494233311(时间戳)",
          "topic_whether_report":"１（１代表被举报）"
      },
      "user_info":{
          "user_id": "9223372036854765807",
          "nickname": "传说中的小哥哥",
          "age": "after_80",
          "avatar": "http://cootek-dialer-download.oss-cn-hangzhou.aliyuncs.com/social_head/head/2255590324019366691.png",
          "sex": "male",
      }
    },
    "req_id": 0,
    "result_code": 2000
}
```

###**(3) 用户举报话题接口：/chat_room/topic_report**

**请求方法**
POST

**请求参数**
|参数名称|参数类型|参数描述|可为空|备注|
|-------|-------|------|----|
|topic_id|string|话题的ｉｄ|否||


**响应参数**
TODO

**示例**

响应结果：
```
{
    "is_ios": false,
    "timestamp": "1494233311",
    "err_msg": "OK",
    "result": "举报成功",
    "req_id": 0,
    "result_code": 2000
}
```

###**(4) 用户点击话题进行聊天数量统计接口：/chat_room/topic_click_to_chat**

**请求方法**
POST

**请求参数**
|参数名称|参数类型|参数描述|可为空|备注|
|-------|-------|------|----|
|topic_id|string|话题的ｉｄ|否||


**响应参数**
TODO

**示例**

响应结果：
```
{
    "is_ios": false,
    "timestamp": "1494233311",
    "err_msg": "OK",
    "result": "suc",
    "req_id": 0,
    "result_code": 2000
}
```

##Q&A
* 每个用户是否只能发布一个话题
Ａ：是
* 用户编辑过话题，我们是否都需要做记录
Ａ：是
* 首页展示多少个话题
Ａ：20
* 每次下拉展示多少个话题
Ａ：20