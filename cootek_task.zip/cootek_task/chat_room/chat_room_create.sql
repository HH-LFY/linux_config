-- 创建聊天室相关的表

-- 聊天室-话题表 chat_room_topic
CREATE TABLE IF NOT EXISTS `chat_room_topic` (
  `chat_room_topic_id` int(11) NOT NULL AUTO_INCREMENT,
  `chat_room_topic_content` varchar(70),
  `chat_room_topic_author_id` varchar(70),
  `chat_room_topic_submit_time` datetime DEFAULT NULL,
  `chat_room_topic_report_end_time` datetime DEFAULT NULL,
  `chat_room_topic_end_time` datetime DEFAULT NULL,
  `chat_room_topic_click_count` int DEFAULT 0,
  `chat_room_topic_enable` int DEFAULT 0,
  PRIMARY KEY (`chat_room_topic_id`),
  INDEX(`chat_room_topic_author_id`),
  INDEX(`chat_room_topic_submit_time`)
) AUTO_INCREMENT = 100000 DEFAULT CHARSET=utf8;

insert into chat_room_topic(chat_room_topic_content,chat_room_topic_author_id)
  values('测试1','135200');
insert into chat_room_topic(chat_room_topic_content,chat_room_topic_author_id)
  values('测试2','9223372036854766224');
insert into chat_room_topic(chat_room_topic_content,chat_room_topic_author_id)
  values('测试1','9223372036854766225');
insert into chat_room_topic(chat_room_topic_content,chat_room_topic_author_id)
  values('测试1','9223372036854766226');
insert into chat_room_topic(chat_room_topic_content,chat_room_topic_author_id)
  values('测试1','9223372036854766227');
insert into chat_room_topic(chat_room_topic_content,chat_room_topic_author_id)
  values('aassa测试测试测试测试测试1','9223372036854766228');
insert into chat_room_topic(chat_room_topic_content,chat_room_topic_author_id)
  values('2221','9223372036854766229');
insert into chat_room_topic(chat_room_topic_content,chat_room_topic_author_id)
  values('测','9223372036854766230');
insert into chat_room_topic(chat_room_topic_content,chat_room_topic_author_id)
  values('测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试','9223372036854766231');


select * from
chat_room_topic, andes_user
where chat_room_topic.chat_room_topic_author_id = '135200'
and chat_room_topic.chat_room_topic_enable = 0
and chat_room_topic.chat_room_topic_author_id = andes_user.user_id
limit 1

select user_id from andes_user where head_image_url>='';

select * from chat_room_topic
where chat_room_topic_author_id = (
  select distinct(chat_room_topic_author_id)
  from chat_room_topic)
limit 1;

-- 聊天室-话题举报表
CREATE TABLE IF NOT EXISTS `chat_room_topic_report` (
  `chat_room_topic_id` int(11) NOT NULL,
  `chat_room_topic_reporter_id` varchar(70) NOT NULL,
  `chat_room_topic_report_time` datetime DEFAULT NULL,
  `chat_room_report_type` int DEFAULT 0,
  INDEX(`chat_room_topic_id`),
  INDEX(`chat_room_topic_reporter_id`),
  UNIQUE(`chat_room_topic_id`,`chat_room_topic_reporter_id`)
)  DEFAULT CHARSET=utf8;

insert into chat_room_topic_report(chat_room_topic_id,chat_room_topic_reporter_id) values('100002','135200');

select * from
chat_room_topic as a, andes_user as b
where a.chat_room_topic_id in (
  select t.chat_room_topic_id from
  (select c.chat_room_topic_id from
  chat_room_topic as c , chat_room_topic_report as d
  where d.chat_room_report_type = 0
  and c.chat_room_topic_enable = 0
  and c.chat_room_topic_author_id != 135200
  and d.chat_room_topic_reporter_id = 135200
  and c.chat_room_topic_id != d.chat_room_topic_id
  and c.chat_room_topic_submit_time < '2019-06-20 13:07:29'
  group by chat_room_topic_id
  having count(*)<3
  order by chat_room_topic_submit_time desc
  limit 20) as t
)
and a.chat_room_topic_author_id = b.user_id

-- 聊天室-白名单表
CREATE TABLE `chat_room_white_list` (
  `phone` varchar(50) NOT NULL,
  `type`int DEFAULT 0,
  `add_time` datetime DEFAULT NULL,
  `remark` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into chat_room_white_list(phone)
  values("+8613197916576")

-- sql
SQL_SELECT_TOPIC_LIST = '''
select * from
chat_room_topic as a, andes_user as b
where a.chat_room_topic_id in (
  select t.chat_room_topic_id from
  (select c.chat_room_topic_id from
  chat_room_topic as c , chat_room_topic_report as d
  where d.chat_room_report_type = 0
  and c.chat_room_topic_enable = 0
  and c.chat_room_topic_author_id != %s
  and d.chat_room_topic_reporter_id = %s
  and c.chat_room_topic_id != d.chat_room_topic_id
  and c.chat_room_topic_submit_time < %s
  group by chat_room_topic_id
  having count(*)<3
  order by chat_room_topic_submit_time desc
  limit %s) as t
)
and a.chat_room_topic_author_id = b.user_id
'''

SQL_SELECT_TOPIC_WHETHER_REPORT = '''
select chat_room_topic_id from
chat_room_topic_report
where chat_room_topic_id = %s
and (chat_room_report_type = 1 or chat_room_topic_id in(
    select b.chat_room_topic_id from
    chat_room_topic_report as b
    group by chat_room_topic_id
    having count(*)>=3))
limit 1
'''
“”