# 订单状态
voice_actor_order_state_remark = {
    # 10 开头代表订单的基本状态
    '101':'待确认',
    '102':'待服务',
    '103':'进行中',

        '104':'申请过退款后主动取消退款的(在用户点击取消退款的时候，未到服务时间) 待服务 状态',
        '105':'申请过退款后主动取消退款的(在用户点击取消退款的时候，已过服务时间，且未超过服务结束时间之后的24小时) 进行中 状态'

    # 20 开头代表订单完成状态 ： 已取消
    '201':'艺人主动拒单，完成退款',
    '202':'超过一定时间，系统默认艺人拒单，完成退款',
    '203':'用户在待确认的时候，取消订单，完成退款',
    '204':'艺人同意用户退款，完成退款',

    # 已完成
    '205':'首次默认完成',
    '206':'用户点击完成',
    '207':'再次默认完成',
        '208':'客服介入后，拒绝退款的完成'，
        '209':'客服介入后，同意退款 并完成退款',
        '210':'申请退款后主动取消退款（在点击取消退款的时候，已过 服务结束时间之后的24小时）的 final 状态',


    # 30 开头代表订单被取消 ：   退款中
    '301':'艺人主动拒单',
    '302':'超过一定时间(超过服务时间)，系统默认艺人拒单',
    '303':'用户在待确认的时候，取消订单'
    '304':'艺人同意用户退款',

    '305':'客服同意退款'

    # 40 开头代表退款状态： 退款中
        '401':'用户申请退款中',

    '402':'艺人拒绝用户退款',
}



user_change_state = {
    '101':{
        'cancel_order':'303',
    },
    '102':{
        'apply_refund':'401',
        'confirm_finish':'206'
    },
    '103':{
        'apply_refund':'401',
        'confirm_finish':'206'
    },
    '104':{
        'confirm_finish':'206',
    },
    '105':{
        'confirm_finish':'206',
    },
    # 已完成
    '201':{
        'delete_order':'201',

    },
    '202':{
        'delete_order':'202',
    },
    '203':{
        'delete_order':'203',
    },
    '204':{
        'delete_order':'204',
        'allow_evaluate':'204'
    },
    '205':{
        'apply_refund':'401',
        'allow_evaluate':'206'
    },
    '206':{
        'delete_order':'206',
        'allow_evaluate':'206'
    },
    '207':{
        'delete_order':'206',
        'allow_evaluate':'207'
    },
    '208':{
        'delete_order':'208'
    },
    '209':{
        'allow_evaluate':'209',
        'delete_order':'209'
    },
    '210':{
        'allow_evaluate':'210',
        'delete_order':'210'
    }
    #  退款中
    # '301':'艺人主动拒单',
    '301':{
    },
    # '302':'超过一定时间，系统默认艺人拒单',
    '302':{
    },
    # '303':'用户在待确认的时候，取消订单'
    '303':{
    },
    # '304':'艺人同意用户退款',
    '304':{
        'allow_evaluate':'304'
    },

    # 40 开头代表退款状态： 退款中
    # '401':'用户申请退款中',
    '401':{
        'cancel_refund':'206',
    },
    # '402':'艺人拒绝用户退款',
    '402':{
    },
}

voice_actor_change_state = {
    '101':{
        'refuse_order':'301',
        'accept_order':'102',
    },
    '102':{
    },
    '103':{
    },
    '104':{
    },
    '105':{
    },
    # 已完成
    '201':{
        'delete_order':'201',

    },
    '202':{
        'delete_order':'202',

    },
    '203':{
        'delete_order':'203',
    },
    '204':{
        'delete_order':'204',
        'allow_evaluate':'204'
    },
    '205':{
        'allow_evaluate':'205'
    },
    '206':{
        'delete_order':'206',
        'allow_evaluate':'206'
    },
    '207':{
        'delete_order':'207',
        'allow_evaluate':'207'
    },
    '208':{
        'delete_order':'208',
        'allow_evaluate':'208'
    },
    '209':{
        'delete_order':'209',
        'allow_evaluate':'209'
    }
    '210':{
        'delete_order':'210',
        'allow_evaluate':'210'
    }
    #  退款中
    # '301':'艺人主动拒单',
    '301':{
        'delete_order':'301'
    },
    # '302':'超过一定时间，系统默认艺人拒单',
    '302':{
        'delete_order':'302',
    },
    # '303':'用户在待确认的时候，取消订单'
    '303':{
        'delete_order':'303',
    },
    # '304':'艺人同意用户退款',
    '304':{
        'delete_order':'304',
        'allow_evaluate':'304'
    },

    # 40 开头代表退款状态： 退款中
    # '401':'用户申请退款中',
    '401':{
        'refuse_refund':'402',
        'accept_refund':'304',
    },
    # '402':'艺人拒绝用户退款',
    '402':{
    },
}


# 评论状态
voice_actor_order_evaluate_state = {
    '0':'订单还未有评论',
    '1':'用户已经评论艺人'，
    '2':'艺人已经评论用户'，
    '3':'艺人用户已经互相评论'
}


# 删除订单表示在某一方不显示此订单
# already_delete 状态
voice_actor_delete_state = {
    '0':'订单都展示',
    '1':'用户删除订单'，
    '2':'艺人删除订单'，
    '3':'艺人用户都删除订单'
}

# 强行更新状态
update voice_actor_order set voice_actor_order_state=102 where voice_actor_order_id='1497427409631_VA_151654';

update voice_actor_order set voice_actor_order_end_time='2017-06-13 17:15:00' where voice_actor_order_id='1497427409631_VA_151654';


# 查询声优订单信息
select * from voice_actor_order where voice_actor_order_user_id='151654' order by voice_actor_order_book_time desc limit 2 \G

#